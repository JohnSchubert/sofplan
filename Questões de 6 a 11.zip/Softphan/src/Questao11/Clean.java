public String statement() {
    double totalDoMontante = 0;
    int PontosFrequentesLocatario = 0;
    Enumeration aluguel = _aluguel.elements();
    String resultado = "Aluguel Record for " + nome() + "\n";
    
    while (aluguel.hasMoreElements()) {
        double thisMontante = 0;
        Aluguel cada = (Aluguel) aluguel.nextElement();
        
        // Determina os montantes para cada linha
        
        switch (cada.getFilme().getCodigoDePreco()) {
            case Filme.REGULAR:
                thisMontante += 2;
                if (cada.getDiasAlugados() > 2) {
                    thisMontante += (cada.getDiasAlugados() - 2) * 1.5;
                }
                break;
                
            case Filme.NEW_RELEASE:
                thisMontante += cada.getDiasAlugados() * 3;
                break;
                
            case Filme.CHILDREN:
                thisMontante += 1.5;
                if (cada.getDiasAlugados() > 3) {
                	thisMontante += (cada.getDiasAlugados() - 3) * 1.5;                	
                }
                break;
        }
        
     // adicione pontos de locatário frequentes        
        PontosFrequentesLocatario++;
        
     // adicione bônus para um novo lançamento de dois dias
        
        if ((cada.getFilme().getCodigoDePreco() == Filme.NEW_RELEASE) && cada.getDiasAlugados() > 1)
            PontosFrequentesLocatario++;
        
        // show figures for this Aluguel
        resultado += "\t" + cada.getFilme().getTitulo() + "\t" + String.valueOf(thisMontante) + "\n";
        totalDoMontante += thisMontante;
    }
    
 // adiciona linhas de rodapé
    resultado += "Amount owed is " + String.valueOf(totalDoMontante) + "\n";
    resultado += "You earned " + String.valueOf(PontosFrequentesLocatario) + " frequent renter points";
    return resultado;
}