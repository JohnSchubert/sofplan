package Questao7;

import javax.swing.JOptionPane;

public class salario {

	public static void main(String[] args) {
		
		int tempoServicoFuncionario = 0;
		double salarioFuncionario = 0.00;
		double salarioNovo;
		
		tempoServicoFuncionario = Integer.parseInt(JOptionPane.showInputDialog("Informe quantos anos completos tem de serviço na empresa."));
		salarioFuncionario = Double.parseDouble(JOptionPane.showInputDialog("Qual o Valor do salário?"));
		
		if((tempoServicoFuncionario > 5) && (salarioFuncionario < 3000.00)) {
			salarioNovo = (salarioFuncionario + (salarioFuncionario * 0.2));
			JOptionPane.showMessageDialog(null, "Seu novo salário é de R$" + salarioNovo);
		}else {
			salarioNovo = (salarioFuncionario + (salarioFuncionario * 0.05));
			JOptionPane.showMessageDialog(null, "Seu novo salário é de R$" + salarioNovo);
		}
	}
}
