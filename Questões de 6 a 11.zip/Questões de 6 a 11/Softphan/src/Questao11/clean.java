public String checkRent() {
	double totalAmount = 0;
	int frequentRenterPoints = 0;
	Enumeration rentals = _rentals.elements();
	String result = "Rental Record for " + name() + "\n";
	
	while (rentals.hasMoreElements()) {
		double thisAmount = 0;
		Rental each = (Rental) rentals.nextElement();
		double daysRented = each.getDaysRented();

		// determine amounts for each line
		thisAmount += amountsForEachRental(each.getMovie().getPriceCode(), daysRented);

		// show figures for this rental
		result += "\t" + each.getMovie().getTitle() + "\t" + String.valueOf(thisAmount) + "\n";
		totalAmount += thisAmount;

		// add bonus for a two day new release rental
		if ((each.getMovie().getPriceCode() == Movie.NEW_RELEASE) && daysRented > 1){
			frequentRenterPoints += 2;
			break;
		}

		frequentRenterPoints++;
		
	}
	// add footer lines
	result += "Amount owed is " + String.valueOf(totalAmount) + "\n";
	result += "You earned " + String.valueOf(frequentRenterPoints) + " frequent renter points";
	return result;
}

public double amountsForEachRental(PriceCode rental, double daysRented) {
	double amount = 0; 
	switch (rental) {
		case Movie.REGULAR:
			if (daysRented > 2){
				amount += (daysRented) * 1.5;
				break;
			}
			
			amount += 2;
			break;
		case Movie.NEW_RELEASE:
			amount += daysRented * 3;
			break;
		case Movie.CHILDREN:
			amount += 1.5;
			if (daysRented > 3) amount += (daysRented - 3) * 1.5;
			break;
	}
	return amount;
}