package Questao9;

import javax.swing.JOptionPane;

public class salario {

	public static void main(String[] args) {

		double salarioFuncionario = 0.00;
		double salarioMinimo = 0.00;
		Double salarioNovo = 0.00;
		String nomeFuncionario = "";
		
		nomeFuncionario = JOptionPane.showInputDialog("Qual o Nome do Funcionário ? ");
		salarioFuncionario = Double.parseDouble(JOptionPane.showInputDialog("Qual o valor do Salário do Funcionario? \n"));
		salarioMinimo = Double.parseDouble(JOptionPane.showInputDialog("Qual o valor do Salário mínimo? \n"));
	
		if(salarioFuncionario < (salarioMinimo * 3 )) {
			salarioNovo = salarioFuncionario + (salarioFuncionario * 0.50); 
			JOptionPane.showMessageDialog(null, nomeFuncionario + " seu reajuste foi de 50% e seu salário foi para R$" + salarioNovo );
		} else if ((salarioFuncionario >= (salarioMinimo * 3 ) && salarioFuncionario <= (salarioMinimo * 10 ))) {
			salarioNovo = salarioFuncionario + (salarioFuncionario * 0.20); 
			JOptionPane.showMessageDialog(null, nomeFuncionario + " seu reajuste foi de 20% e seu salário foi para R$" + salarioNovo );
		}else if ((salarioFuncionario > (salarioMinimo * 10)) && (salarioFuncionario <= (salarioMinimo * 20 ))){
			salarioNovo = salarioFuncionario + (salarioFuncionario * 0.15); 
			JOptionPane.showMessageDialog(null, nomeFuncionario + " seu reajuste foi de 15% e seu salário foi para R$" + salarioNovo );
		}else if((salarioFuncionario > (salarioMinimo * 20 ))) {
			salarioNovo = salarioFuncionario + (salarioFuncionario * 0.10); 
			JOptionPane.showMessageDialog(null, nomeFuncionario + " seu reajuste foi de 10% e seu salário foi para R$" + salarioNovo );
		}
	}
}
