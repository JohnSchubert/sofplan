
package Questao6;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class carro {

		public static void main(String[] args) {
		
		int ano =0;
		String nome = "";
		Double valor = 0.00 ; 
		Double desconto = 0.00;
		

		nome = JOptionPane.showInputDialog("Qual a Marca do carro escolhido?  ");
		valor = Double.parseDouble(JOptionPane.showInputDialog("Qual o Valor do carro escolhido? "));
		ano = Integer.parseInt(JOptionPane.showInputDialog("Qual o ano do carro escolhido? "));
		
		if(ano <= 2000) {
			desconto = (valor * 0.12);
			valor -= desconto ;
		}else {
			desconto = (valor * 0.07);
			valor -= desconto;
		}		
		
		JOptionPane.showMessageDialog(null, "O valor do do seu "+ nome + " foi  de R$" + desconto + " e o valor to carro ficou por R$" + valor);
	}
		
		public static boolean isInt(String text) {
		    try {
		        Integer.parseInt(text);
		        return true;
		    } catch (Exception e) {
		        return false;
		    }
		}	
}