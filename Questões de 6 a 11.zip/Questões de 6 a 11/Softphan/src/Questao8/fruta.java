package Questao8;

import javax.swing.JOptionPane;

public class fruta {

	public static void main(String[] args) {

		double morangoAte5 = 2.50;
		double morangoMais5 = 2.20;
		double macaAte5 = 1.80;
		double macaMais5 = 1.50;
		double qtdMaca = 0.00;
		double qtdMorango = 0.00;
		double totalFrutas = 0.00;
		double valorTotalMacas = 0.00;
		double valorTotalMorangos = 0.00;
		double valorTotalFrutas = 0.00;
		
		qtdMorango = Double.parseDouble(JOptionPane.showInputDialog("Quantos Kg de morangos vai comprar? \n"));
		qtdMaca = Double.parseDouble(JOptionPane.showInputDialog("Quantos Kg de maçãs vai comprar? \n"));
		
		totalFrutas = qtdMaca + qtdMorango;
		
		JOptionPane.showMessageDialog(null, "O total de Morangos comprados foi " + qtdMorango + "Kg\n" +
											"O total de Maçãs compradas foi " + qtdMaca + "Kg\n" +
											"E o total de Frutas comprados foi " + totalFrutas + "Kg");	
		
		
		if(qtdMaca > 5) {
			valorTotalMacas =  qtdMaca * macaMais5;
		}else {
			valorTotalMacas =  qtdMaca * macaAte5;
		}
		if(qtdMorango > 5) {
			valorTotalMorangos = qtdMorango * morangoMais5;
		}else {
			valorTotalMorangos = qtdMorango * morangoAte5;
		}
		valorTotalFrutas = valorTotalMacas + valorTotalMorangos;
		
		if(totalFrutas > 8.00 || valorTotalFrutas > 25.00 ) {
			valorTotalFrutas = valorTotalFrutas -  (valorTotalFrutas * 0.10);
			
			JOptionPane.showMessageDialog(null, "O valor total de Morangos comprados foi de R$" + valorTotalMorangos + "\n" +
					"O Valor total de Maçãs compradas foi de R$" + valorTotalMacas + "\n" +
					"E o valor total de Frutas comprados foi de R$" + valorTotalFrutas + " pois teve o desconto de R$" + (valorTotalFrutas * 0.10));	

		} else {
			JOptionPane.showMessageDialog(null, "O valor total de Morangos comprados foi de R$" + valorTotalMorangos + "\n" +
					"O Valor total de Maçãs compradas foi de R$" + valorTotalMacas + "\n" +
					"E o valor total de Frutas comprados foi de R$" + valorTotalFrutas);	
		}
		
		
	}

}
