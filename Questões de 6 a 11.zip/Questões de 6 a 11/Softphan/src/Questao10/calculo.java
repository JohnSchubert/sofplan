package Questao10;

import javax.swing.JOptionPane;

public class calculo {

	public static void main(String[] args) {
		calculo calc = new calculo();
		calc.calulcarProduto();

	}
	
	public void calulcarProduto() {
		int resultadoNumeros = resultadoNumeros();
		JOptionPane.showMessageDialog(null,"A multiplicação dos números resulta em " + resultadoNumeros + ".");
	}
	
	public Integer resultadoNumeros() {
		int resultadoN2 = 0; 
		int n1Impar = 0;
		int divisaoN1 = 0;
		int n1 = 0; 
		int n2 = 0;
		
		n1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
		divisaoN1 = n1;
		n2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));
		resultadoN2 = n2;
		
		JOptionPane.showMessageDialog(null, (n1 + " | " + n2));
		
		for (int x = 0; x < n1; x++) {
			/**/
			if (divisaoN1 % 2 != 0) {
				n1Impar = resultadoN2;
			}
			resultadoN2 = resultadoN2 * 2;
			/*Divisão do n1*/
			divisaoN1 = (divisaoN1 / 2);
			JOptionPane.showMessageDialog (null, (divisaoN1 + " | " + resultadoN2));
			if (divisaoN1 == 1) {
				break;
			}
		}
		return (n1Impar + resultadoN2);
	}
}