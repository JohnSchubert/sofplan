package testes;

import crud.Cliente;
import repositorio.RepositorioCliente;
import java.util.List;

public class Teste {

	public static void main(String[] args) {

		RepositorioCliente repositorioCliente = new RepositorioCliente();
	/*	Cliente cliente = new Cliente();
		cliente.setNome("Primeiro");
		cliente.setSexo("M");
		cliente.setEndereco("Japão");
		cliente.setCpf("000.000.000-00");
		cliente.setStatus(true);
		
		repositorioCliente.salvar(cliente);
		*/
		
/*		List<Cliente> clientes = repositorioCliente.listarTodos();
		
		for(Cliente cliente : clientes){
			System.out.println(cliente.getNome());
		}
 */
	}
	
	

}
